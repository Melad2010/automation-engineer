<?php
/**
 * Plugin Name: Northside Booking Requests
 * Description: Booking requests for an invented bicycle repair shop. All demo content is synthetic sample data.
 * Version: 1.0.0
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: northside-booking
 */

defined( 'ABSPATH' ) || exit;
define( 'NSB_VERSION', '1.0.0' );
define( 'NSB_FILE', __FILE__ );
require_once __DIR__ . '/includes/class-nsb-plugin.php';
require_once __DIR__ . '/includes/class-nsb-admin.php';
register_activation_hook( __FILE__, array( 'NSB_Plugin', 'activate' ) );
NSB_Plugin::boot();
NSB_Admin::boot();
