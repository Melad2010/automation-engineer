/* Progressive enhancement: the HTML form remains fully usable without this file. */
(function () {
    'use strict';
    if (!window.fetch || !window.FormData) return;
    document.querySelectorAll('.nsb-form').forEach(function (form) {
        form.addEventListener('submit', async function (event) {
            event.preventDefault();
            var button = form.querySelector('button[type="submit"]');
            if (button.disabled) return;
            var message = form.closest('.nsb').querySelector('.nsb-message');
            form.querySelectorAll('[data-error-for]').forEach(function (el) { el.textContent = ''; });
            form.querySelectorAll('[aria-invalid]').forEach(function (el) { el.setAttribute('aria-invalid', 'false'); });
            button.disabled = true;
            form.setAttribute('aria-busy', 'true');
            try {
                var response = await fetch(form.dataset.endpoint, {
                    method: 'POST', credentials: 'same-origin',
                    headers: { 'X-WP-Nonce': form.dataset.restNonce },
                    body: new FormData(form)
                });
                var result = await response.json();
                if (typeof result.message !== 'string') throw new Error('Unexpected response');
                message.textContent = result.message;
                message.classList.toggle('nsb-success', result.success === true);
                Object.keys(result.errors || {}).forEach(function (field) {
                    var input = form.elements.namedItem(field);
                    var error = form.querySelector('[data-error-for="' + field + '"]');
                    if (input && error) {
                        input.setAttribute('aria-invalid', 'true');
                        error.textContent = result.errors[field];
                    }
                });
                if (result.success) form.reset();
            } catch (error) {
                // Never automatically repeat an uncertain POST: it may already have saved.
                message.textContent = form.dataset.failure;
                message.classList.remove('nsb-success');
            } finally {
                message.hidden = false;
                message.focus();
                var first = form.querySelector('[aria-invalid="true"]');
                if (first) first.focus();
                button.disabled = false;
                form.removeAttribute('aria-busy');
            }
        });
    });
}());
