(function (blocks, element, editor, i18n) {
    'use strict';
    blocks.registerBlockType('northside/booking', {
        apiVersion: 3,
        title: i18n.__('Northside Booking', 'northside-booking'),
        icon: 'calendar-alt', category: 'widgets',
        edit: function () {
            return element.createElement('div', editor.useBlockProps(),
                element.createElement('strong', null, i18n.__('Northside Booking Requests', 'northside-booking')),
                element.createElement('p', null, i18n.__('The live booking form renders on the published page. Configure services in Booking requests → Settings.', 'northside-booking')));
        },
        save: function () { return null; }
    });
}(window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.i18n));
