<?php
/** Front-end rendering, submission and storage. */
defined( 'ABSPATH' ) || exit;

final class NSB_Plugin {
    const TYPE = 'nsb_request';
    const CAP = 'manage_nsb_requests';
    const OPTION = 'nsb_settings';
    const LIMIT = 5;
    const WINDOW = 600;

    public static function boot() {
        add_action( 'init', array( __CLASS__, 'register' ) );
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
        add_action( 'template_redirect', array( __CLASS__, 'no_cache' ) );
        add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
        add_action( 'admin_post_nsb_submit', array( __CLASS__, 'post' ) );
        add_action( 'admin_post_nopriv_nsb_submit', array( __CLASS__, 'post' ) );
        add_shortcode( 'northside_booking', array( __CLASS__, 'render' ) );
    }

    public static function defaults() {
        return array(
            'services' => array( __( 'Safety check', 'northside-booking' ), __( 'Puncture repair', 'northside-booking' ), __( 'Brake service', 'northside-booking' ), __( 'Full tune-up', 'northside-booking' ) ),
            'notification_email' => sanitize_email( get_option( 'admin_email', '' ) ),
            'success_text' => __( 'Request received. The shop will contact you to confirm a time.', 'northside-booking' ),
            'delete_data' => false,
        );
    }

    public static function settings() {
        return wp_parse_args( get_option( self::OPTION, array() ), self::defaults() );
    }

    public static function activate( $network_wide = false ) {
        if ( is_multisite() && $network_wide ) {
            wp_die( esc_html__( 'Activate Northside Booking Requests separately on each site.', 'northside-booking' ) );
        }
        $role = get_role( 'administrator' );
        if ( $role ) {
            $role->add_cap( self::CAP );
        }
        add_option( self::OPTION, self::defaults(), '', false );
    }

    public static function states() {
        return array(
            'new' => __( 'New', 'northside-booking' ),
            'confirmed' => __( 'Confirmed', 'northside-booking' ),
            'done' => __( 'Done', 'northside-booking' ),
            'cancelled' => __( 'Cancelled', 'northside-booking' ),
        );
    }

    public static function register() {
        load_plugin_textdomain( 'northside-booking', false, dirname( plugin_basename( NSB_FILE ) ) . '/languages' );
        register_post_type( self::TYPE, array(
            'labels' => array(
                'name' => __( 'Booking requests', 'northside-booking' ),
                'singular_name' => __( 'Booking request', 'northside-booking' ),
                'edit_item' => __( 'View booking request', 'northside-booking' ),
                'not_found' => __( 'No booking requests found.', 'northside-booking' ),
            ),
            'public' => false, 'publicly_queryable' => false, 'exclude_from_search' => true,
            'show_ui' => true, 'show_in_rest' => false, 'rewrite' => false, 'query_var' => false,
            'menu_icon' => 'dashicons-calendar-alt', 'supports' => array(), 'map_meta_cap' => true,
            'capability_type' => array( 'nsb_request', 'nsb_requests' ),
            'capabilities' => array(
                'edit_posts' => self::CAP, 'edit_others_posts' => self::CAP, 'publish_posts' => self::CAP,
                'read_private_posts' => self::CAP, 'delete_posts' => self::CAP,
                'delete_private_posts' => self::CAP, 'delete_published_posts' => self::CAP,
                'delete_others_posts' => self::CAP, 'edit_private_posts' => self::CAP,
                'edit_published_posts' => self::CAP, 'create_posts' => 'do_not_allow',
            ),
        ) );
        foreach ( array( 'name', 'email', 'phone', 'service', 'date', 'notes', 'state', 'mail_status' ) as $field ) {
            register_post_meta( self::TYPE, '_nsb_' . $field, array(
                'type' => 'string', 'single' => true, 'show_in_rest' => false,
                'sanitize_callback' => 'notes' === $field ? 'sanitize_textarea_field' : 'sanitize_text_field',
                'auth_callback' => static function () { return current_user_can( self::CAP ); },
            ) );
        }
        wp_register_script( 'nsb-block', plugins_url( 'assets/block.js', NSB_FILE ), array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-i18n' ), NSB_VERSION, true );
        wp_set_script_translations( 'nsb-block', 'northside-booking' );
        register_block_type( dirname( NSB_FILE ), array( 'render_callback' => array( __CLASS__, 'render' ) ) );
    }

    public static function assets() {
        // Small, dependency-free assets also support forms placed in template parts/widgets.
        wp_enqueue_style( 'nsb-form', plugins_url( 'assets/form.css', NSB_FILE ), array(), NSB_VERSION );
        wp_enqueue_script( 'nsb-form', plugins_url( 'assets/form.js', NSB_FILE ), array(), NSB_VERSION, true );
    }

    public static function no_cache() {
        $post = get_queried_object();
        if ( isset( $_GET['nsb_notice'] ) || ( $post instanceof WP_Post && ( has_shortcode( $post->post_content, 'northside_booking' ) || has_block( 'northside/booking', $post ) ) ) ) {
            nocache_headers();
        }
    }

    public static function visitor_hash() {
        // Do not trust spoofable forwarding headers or persist the address itself.
        $address = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : 'unknown';
        return hash_hmac( 'sha256', $address, wp_salt( 'nonce' ) );
    }

    public static function remember( $key, $value, $ttl ) {
        set_transient( $key, $value, $ttl );
        // A bounded-by-expiry index lets uninstall remove transients without direct SQL.
        $index = get_option( 'nsb_transients', array() );
        foreach ( $index as $old => $expiry ) {
            if ( $expiry < time() ) {
                delete_transient( $old );
                unset( $index[ $old ] );
            }
        }
        $index[ $key ] = time() + $ttl;
        update_option( 'nsb_transients', $index, false );
    }

    public static function render() {
        $settings = self::settings();
        $values = array_fill_keys( array( 'name', 'email', 'phone', 'service', 'date', 'notes' ), '' );
        $errors = array();
        $message = '';
        $success = false;
        $notice = isset( $_GET['nsb_notice'] ) && is_string( $_GET['nsb_notice'] ) ? sanitize_key( wp_unslash( $_GET['nsb_notice'] ) ) : '';
        if ( preg_match( '/^[a-f0-9]{32}$/', $notice ) ) {
            $key = 'nsb_flash_' . $notice;
            $flash = get_transient( $key );
            if ( is_array( $flash ) && hash_equals( $flash['visitor'], self::visitor_hash() ) ) {
                delete_transient( $key );
                $values = $flash['values'];
                $errors = $flash['errors'];
                $message = $flash['message'];
                $success = $flash['success'];
            }
        }
        $id = wp_unique_id( 'nsb-' );
        $return_url = get_permalink() ? get_permalink() : home_url( '/' );
        ob_start();
        require dirname( NSB_FILE ) . '/templates/form.php';
        return ob_get_clean();
    }

    public static function scalar( $data, $field ) {
        return isset( $data[ $field ] ) && is_string( $data[ $field ] ) ? trim( $data[ $field ] ) : '';
    }

    public static function submit( $data ) {
        $empty = array( 'success' => false, 'values' => array(), 'errors' => array() );
        if ( ! wp_verify_nonce( self::scalar( $data, 'nsb_nonce' ), 'nsb_submit' ) ) {
            return array_merge( $empty, array( 'status' => 403, 'message' => __( 'Your form has expired. Reload the page and try again.', 'northside-booking' ) ) );
        }
        if ( ! empty( $data['website'] ) ) {
            return array_merge( $empty, array( 'status' => 400, 'message' => __( 'This request could not be accepted.', 'northside-booking' ) ) );
        }
        $rate_key = 'nsb_rate_' . self::visitor_hash();
        $rate = get_transient( $rate_key );
        if ( ! is_array( $rate ) ) {
            $rate = array( 'count' => 0, 'until' => time() + self::WINDOW );
        }
        if ( $rate['count'] >= self::LIMIT ) {
            return array_merge( $empty, array( 'status' => 429, 'message' => __( 'Too many requests. Please try again in ten minutes.', 'northside-booking' ) ) );
        }
        ++$rate['count'];
        self::remember( $rate_key, $rate, max( 1, $rate['until'] - time() ) );
        $raw = array();
        $values = array();
        foreach ( array( 'name', 'email', 'phone', 'service', 'date', 'notes' ) as $field ) {
            $raw[ $field ] = self::scalar( $data, $field );
            $values[ $field ] = 'notes' === $field ? sanitize_textarea_field( $raw[ $field ] ) : sanitize_text_field( $raw[ $field ] );
        }
        $errors = array();
        if ( '' === $values['name'] || strlen( $raw['name'] ) > 100 ) {
            $errors['name'] = __( 'Enter a name of 100 characters or fewer.', 'northside-booking' );
        }
        if ( ! is_email( $raw['email'] ) || strlen( $raw['email'] ) > 254 ) {
            $errors['email'] = __( 'Enter a valid email address.', 'northside-booking' );
        }
        if ( '' !== $raw['phone'] && ( strlen( $raw['phone'] ) > 40 || ! preg_match( '/^[+0-9(). \-]+$/', $raw['phone'] ) || ! preg_match( '/[0-9]/', $raw['phone'] ) ) ) {
            $errors['phone'] = __( 'Use digits and standard phone punctuation, up to 40 characters.', 'northside-booking' );
        }
        $settings = self::settings();
        if ( ! in_array( $raw['service'], $settings['services'], true ) ) {
            $errors['service'] = __( 'Choose a service from the list.', 'northside-booking' );
        }
        $date = DateTimeImmutable::createFromFormat( '!Y-m-d', $raw['date'], wp_timezone() );
        if ( ! $date || $date->format( 'Y-m-d' ) !== $raw['date'] || $raw['date'] < current_time( 'Y-m-d' ) ) {
            $errors['date'] = __( 'Choose a valid date today or later.', 'northside-booking' );
        }
        if ( strlen( $raw['notes'] ) > 2000 ) {
            $errors['notes'] = __( 'Keep notes to 2000 characters or fewer.', 'northside-booking' );
        }
        if ( $errors ) {
            // Bound temporary retained values even for a malicious oversized payload.
            foreach ( $values as $field => $value ) {
                $values[ $field ] = substr( $value, 0, 'notes' === $field ? 2000 : 254 );
            }
            return array( 'success' => false, 'status' => 422, 'errors' => $errors, 'values' => $values, 'message' => __( 'Please check the highlighted fields.', 'northside-booking' ) );
        }
        $values['email'] = sanitize_email( $raw['email'] );
        $meta = array( '_nsb_state' => 'new' );
        foreach ( $values as $field => $value ) {
            $meta[ '_nsb_' . $field ] = $value;
        }
        $post_id = wp_insert_post( wp_slash( array(
            'post_type' => self::TYPE, 'post_status' => 'private', 'post_title' => $values['name'], 'meta_input' => $meta,
        ) ), true );
        if ( is_wp_error( $post_id ) ) {
            return array_merge( $empty, array( 'status' => 500, 'message' => __( 'The request could not be saved. Please try again.', 'northside-booking' ) ) );
        }
        $sent = false;
        if ( is_email( $settings['notification_email'] ) ) {
            $sent = wp_mail(
                $settings['notification_email'],
                __( 'New booking request', 'northside-booking' ),
                sprintf(
                    /* translators: 1: request number, 2: service, 3: preferred date, 4: admin URL. */
                    __( "Booking request #%1\$d\nService: %2\$s\nPreferred date: %3\$s\nReview securely: %4\$s", 'northside-booking' ),
                    $post_id, $values['service'], $values['date'], admin_url( 'post.php?post=' . $post_id . '&action=edit' )
                )
            );
        }
        update_post_meta( $post_id, '_nsb_mail_status', $sent ? 'sent' : 'not_sent' );
        return array( 'success' => true, 'status' => 201, 'message' => $settings['success_text'], 'errors' => array(), 'values' => array() );
    }

    public static function post() {
        if ( 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
            wp_die( esc_html__( 'Use the booking form to submit a request.', 'northside-booking' ), '', array( 'response' => 405 ) );
        }
        $data = wp_unslash( $_POST );
        $result = self::submit( $data );
        $notice = bin2hex( random_bytes( 16 ) );
        $result['visitor'] = self::visitor_hash();
        self::remember( 'nsb_flash_' . $notice, $result, 300 );
        $return = wp_validate_redirect( self::scalar( $data, 'nsb_return' ), home_url( '/' ) );
        $return = remove_query_arg( array( 'nsb_notice' ), $return );
        nocache_headers();
        wp_safe_redirect( add_query_arg( 'nsb_notice', $notice, $return ) . '#northside-booking', 303 );
        exit;
    }

    public static function routes() {
        register_rest_route( 'northside-booking/v1', '/requests', array(
            'methods' => 'POST',
            // Public intake is intentional; nonce, honeypot, rate limit and validation run below.
            'permission_callback' => '__return_true',
            'callback' => static function ( WP_REST_Request $request ) {
                $result = self::submit( $request->get_params() );
                $status = $result['status'];
                unset( $result['values'], $result['status'] );
                $response = new WP_REST_Response( $result, $status );
                $response->header( 'Cache-Control', 'no-store' );
                if ( 429 === $status ) {
                    $response->header( 'Retry-After', (string) self::WINDOW );
                }
                return $response;
            },
        ) );
    }
}
