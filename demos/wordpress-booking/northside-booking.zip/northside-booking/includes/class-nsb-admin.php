<?php
/** Capability-protected administration using native WordPress screens. */
defined( 'ABSPATH' ) || exit;

final class NSB_Admin {
    public static function boot() {
        add_filter( 'manage_nsb_request_posts_columns', array( __CLASS__, 'columns' ) );
        add_action( 'manage_nsb_request_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );
        add_filter( 'post_row_actions', array( __CLASS__, 'actions' ), 10, 2 );
        add_action( 'admin_post_nsb_state', array( __CLASS__, 'change_state' ) );
        add_action( 'restrict_manage_posts', array( __CLASS__, 'filter' ) );
        add_action( 'pre_get_posts', array( __CLASS__, 'filter_query' ) );
        add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
        add_action( 'admin_init', array( __CLASS__, 'settings' ) );
        add_action( 'add_meta_boxes_nsb_request', array( __CLASS__, 'boxes' ) );
        add_action( 'wp_dashboard_setup', array( __CLASS__, 'dashboard' ) );
        add_filter( 'option_page_capability_nsb_settings_group', static function () { return NSB_Plugin::CAP; } );
    }

    public static function columns() {
        return array(
            'cb' => '<input type="checkbox" />', 'title' => __( 'Name', 'northside-booking' ),
            'nsb_service' => __( 'Service', 'northside-booking' ), 'nsb_date' => __( 'Preferred date', 'northside-booking' ),
            'nsb_state' => __( 'State', 'northside-booking' ), 'nsb_received' => __( 'Received', 'northside-booking' ),
            'nsb_mail' => __( 'Notification', 'northside-booking' ),
        );
    }

    public static function column( $column, $post_id ) {
        if ( 'nsb_received' === $column ) {
            echo esc_html( get_the_date( 'Y-m-d H:i', $post_id ) );
        } elseif ( 'nsb_state' === $column ) {
            $state = get_post_meta( $post_id, '_nsb_state', true );
            $states = NSB_Plugin::states();
            echo esc_html( isset( $states[ $state ] ) ? $states[ $state ] : $state );
        } elseif ( 'nsb_mail' === $column ) {
            echo esc_html( 'sent' === get_post_meta( $post_id, '_nsb_mail_status', true ) ? __( 'Handed to mailer', 'northside-booking' ) : __( 'Not sent / sample', 'northside-booking' ) );
        } elseif ( in_array( $column, array( 'nsb_service', 'nsb_date' ), true ) ) {
            echo esc_html( get_post_meta( $post_id, '_' . $column, true ) );
        }
    }

    public static function actions( $actions, $post ) {
        if ( NSB_Plugin::TYPE !== $post->post_type || ! current_user_can( NSB_Plugin::CAP ) ) {
            return $actions;
        }
        unset( $actions['inline hide-if-no-js'] );
        foreach ( NSB_Plugin::states() as $state => $label ) {
            if ( get_post_meta( $post->ID, '_nsb_state', true ) === $state ) {
                continue;
            }
            $url = add_query_arg( array( 'action' => 'nsb_state', 'request_id' => $post->ID, 'state' => $state ), admin_url( 'admin-post.php' ) );
            $url = wp_nonce_url( $url, 'nsb_state_' . $post->ID . '_' . $state );
            /* translators: %s: booking state. */
            $actions[ 'nsb_' . $state ] = '<a href="' . esc_url( $url ) . '">' . esc_html( sprintf( __( 'Mark %s', 'northside-booking' ), $label ) ) . '</a>';
        }
        return $actions;
    }

    public static function change_state() {
        if ( ! current_user_can( NSB_Plugin::CAP ) ) {
            wp_die( esc_html__( 'You cannot manage booking requests.', 'northside-booking' ), '', array( 'response' => 403 ) );
        }
        $id = isset( $_GET['request_id'] ) ? absint( $_GET['request_id'] ) : 0;
        $state = isset( $_GET['state'] ) && is_string( $_GET['state'] ) ? sanitize_key( wp_unslash( $_GET['state'] ) ) : '';
        check_admin_referer( 'nsb_state_' . $id . '_' . $state );
        if ( NSB_Plugin::TYPE !== get_post_type( $id ) || ! isset( NSB_Plugin::states()[ $state ] ) || ! current_user_can( 'edit_post', $id ) ) {
            wp_die( esc_html__( 'Invalid request or state.', 'northside-booking' ), '', array( 'response' => 400 ) );
        }
        update_post_meta( $id, '_nsb_state', $state );
        wp_safe_redirect( admin_url( 'edit.php?post_type=nsb_request' ), 303 );
        exit;
    }

    public static function filter( $post_type ) {
        if ( NSB_Plugin::TYPE !== $post_type || ! current_user_can( NSB_Plugin::CAP ) ) {
            return;
        }
        $selected = isset( $_GET['nsb_state'] ) && is_string( $_GET['nsb_state'] ) ? sanitize_key( wp_unslash( $_GET['nsb_state'] ) ) : '';
        echo '<label class="screen-reader-text" for="nsb-state-filter">' . esc_html__( 'Filter by state', 'northside-booking' ) . '</label><select id="nsb-state-filter" name="nsb_state"><option value="">' . esc_html__( 'All states', 'northside-booking' ) . '</option>';
        foreach ( NSB_Plugin::states() as $value => $label ) {
            echo '<option value="' . esc_attr( $value ) . '" ' . selected( $selected, $value, false ) . '>' . esc_html( $label ) . '</option>';
        }
        echo '</select>';
    }

    public static function filter_query( $query ) {
        if ( ! is_admin() || ! $query->is_main_query() || NSB_Plugin::TYPE !== $query->get( 'post_type' ) || ! current_user_can( NSB_Plugin::CAP ) ) {
            return;
        }
        $state = isset( $_GET['nsb_state'] ) && is_string( $_GET['nsb_state'] ) ? sanitize_key( wp_unslash( $_GET['nsb_state'] ) ) : '';
        if ( isset( NSB_Plugin::states()[ $state ] ) ) {
            $query->set( 'meta_key', '_nsb_state' );
            $query->set( 'meta_value', $state );
        }
    }

    public static function menu() {
        add_submenu_page( 'edit.php?post_type=nsb_request', __( 'Booking settings', 'northside-booking' ), __( 'Settings', 'northside-booking' ), NSB_Plugin::CAP, 'nsb-settings', array( __CLASS__, 'page' ) );
    }

    public static function settings() {
        register_setting( 'nsb_settings_group', NSB_Plugin::OPTION, array( 'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ), 'default' => NSB_Plugin::defaults() ) );
        add_settings_section( 'nsb_main', __( 'Request form & notifications', 'northside-booking' ), static function () {
            echo '<p>' . esc_html__( 'Synthetic sample: Northside Bike Repair is an invented shop. A request is not a confirmed appointment.', 'northside-booking' ) . '</p>';
        }, 'nsb-settings' );
        $labels = array(
            'services' => __( 'Services', 'northside-booking' ), 'notification_email' => __( 'Notification email', 'northside-booking' ),
            'success_text' => __( 'Success text', 'northside-booking' ), 'delete_data' => __( 'Uninstall cleanup', 'northside-booking' ),
        );
        foreach ( $labels as $key => $label ) {
            add_settings_field( $key, $label, array( __CLASS__, 'field' ), 'nsb-settings', 'nsb_main', array( 'key' => $key, 'label_for' => 'nsb-setting-' . $key ) );
        }
    }

    public static function sanitize_settings( $input ) {
        $old = NSB_Plugin::settings();
        if ( ! current_user_can( NSB_Plugin::CAP ) || ! is_array( $input ) ) {
            return $old;
        }
        $services = preg_split( '/\r\n|\r|\n/', NSB_Plugin::scalar( $input, 'services' ) );
        $services = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', $services ) ) ) );
        if ( ! $services || count( $services ) > 20 || max( array_map( 'strlen', $services ) ) > 100 ) {
            add_settings_error( NSB_Plugin::OPTION, 'services', __( 'Enter 1 to 20 services, each up to 100 characters.', 'northside-booking' ) );
            $services = $old['services'];
        }
        $email = NSB_Plugin::scalar( $input, 'notification_email' );
        if ( ! is_email( $email ) ) {
            add_settings_error( NSB_Plugin::OPTION, 'email', __( 'Enter a valid notification email.', 'northside-booking' ) );
            $email = $old['notification_email'];
        }
        $success = sanitize_textarea_field( NSB_Plugin::scalar( $input, 'success_text' ) );
        if ( '' === $success || strlen( $success ) > 500 ) {
            add_settings_error( NSB_Plugin::OPTION, 'success', __( 'Enter success text of 500 characters or fewer.', 'northside-booking' ) );
            $success = $old['success_text'];
        }
        return array( 'services' => $services, 'notification_email' => sanitize_email( $email ), 'success_text' => $success, 'delete_data' => ! empty( $input['delete_data'] ) );
    }

    public static function field( $args ) {
        $key = $args['key'];
        $value = NSB_Plugin::settings()[ $key ];
        $attrs = ' id="nsb-setting-' . esc_attr( $key ) . '" name="nsb_settings[' . esc_attr( $key ) . ']"';
        if ( 'delete_data' === $key ) {
            echo '<label><input type="checkbox"' . $attrs . ' value="1" ' . checked( $value, true, false ) . '> ' . esc_html__( 'Permanently remove requests when the plugin is uninstalled.', 'northside-booking' ) . '</label><p class="description">' . esc_html__( 'Off by default. Deactivation never deletes requests.', 'northside-booking' ) . '</p>';
        } elseif ( 'notification_email' === $key ) {
            echo '<input type="email" class="regular-text" required' . $attrs . ' value="' . esc_attr( $value ) . '"><p class="description">' . esc_html__( 'Use an address you control on a real site. The demo uses a reserved synthetic address and suppresses outgoing mail.', 'northside-booking' ) . '</p>';
        } else {
            echo '<textarea class="large-text" rows="5" required' . $attrs . '>' . esc_textarea( is_array( $value ) ? implode( "\n", $value ) : $value ) . '</textarea>';
            if ( 'services' === $key ) {
                echo '<p class="description">' . esc_html__( 'One service per line. Up to 20 services.', 'northside-booking' ) . '</p>';
            }
        }
    }

    public static function page() {
        if ( ! current_user_can( NSB_Plugin::CAP ) ) {
            return;
        }
        echo '<div class="wrap"><h1>' . esc_html__( 'Booking settings', 'northside-booking' ) . '</h1>';
        settings_errors();
        echo '<form method="post" action="options.php">';
        settings_fields( 'nsb_settings_group' );
        do_settings_sections( 'nsb-settings' );
        submit_button();
        echo '</form></div>';
    }

    public static function boxes() {
        remove_meta_box( 'submitdiv', NSB_Plugin::TYPE, 'side' );
        add_meta_box( 'nsb-details', __( 'Request details', 'northside-booking' ), static function ( $post ) {
            if ( ! current_user_can( NSB_Plugin::CAP ) ) {
                return;
            }
            $labels = array( 'name' => __( 'Name', 'northside-booking' ), 'email' => __( 'Email', 'northside-booking' ), 'phone' => __( 'Phone', 'northside-booking' ), 'service' => __( 'Service', 'northside-booking' ), 'date' => __( 'Preferred date', 'northside-booking' ), 'notes' => __( 'Notes', 'northside-booking' ) );
            echo '<dl>';
            foreach ( $labels as $key => $label ) {
                echo '<dt><strong>' . esc_html( $label ) . '</strong></dt><dd style="white-space:pre-wrap;margin:0 0 1em">' . esc_html( get_post_meta( $post->ID, '_nsb_' . $key, true ) ) . '</dd>';
            }
            echo '</dl><p>' . implode( ' | ', self::actions( array(), $post ) ) . '</p>';
        }, NSB_Plugin::TYPE );
    }

    public static function dashboard() {
        if ( current_user_can( NSB_Plugin::CAP ) ) {
            wp_add_dashboard_widget( 'nsb-dashboard', __( 'Booking requests by state', 'northside-booking' ), array( __CLASS__, 'counts' ) );
        }
    }

    public static function counts() {
        if ( ! current_user_can( NSB_Plugin::CAP ) ) {
            return;
        }
        echo '<ul>';
        foreach ( NSB_Plugin::states() as $state => $label ) {
            $query = new WP_Query( array( 'post_type' => NSB_Plugin::TYPE, 'post_status' => 'private', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_nsb_state', 'meta_value' => $state ) );
            $url = add_query_arg( array( 'post_type' => NSB_Plugin::TYPE, 'nsb_state' => $state ), admin_url( 'edit.php' ) );
            echo '<li><a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>: <strong data-nsb-count="' . esc_attr( $state ) . '">' . esc_html( (string) $query->found_posts ) . '</strong></li>';
        }
        echo '</ul><p>' . esc_html__( 'Requests await manual confirmation. Sample data only in the demo.', 'northside-booking' ) . '</p>';
    }
}
