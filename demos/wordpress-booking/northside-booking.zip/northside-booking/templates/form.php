<?php defined( 'ABSPATH' ) || exit; ?>
<section class="nsb" id="northside-booking" aria-labelledby="<?php echo esc_attr( $id ); ?>title">
    <aside class="nsb-intro">
        <span class="nsb-kicker"><?php esc_html_e( 'SYNTHETIC SAMPLE / BIKE WORKSHOP', 'northside-booking' ); ?></span>
        <svg class="nsb-bike" viewBox="0 0 180 100" width="180" height="100" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="3"><circle cx="37" cy="65" r="27"/><circle cx="142" cy="65" r="27"/><path d="M37 65 63 22 93 65H37l18-31h65l22 31M93 65l27-45h-14M53 21h23"/></svg>
        <h2 id="<?php echo esc_attr( $id ); ?>title"><?php esc_html_e( 'Northside Bike Repair', 'northside-booking' ); ?></h2>
        <p class="nsb-lead"><?php esc_html_e( 'A little care. A better ride.', 'northside-booking' ); ?></p>
        <p><?php esc_html_e( 'Tell us what your bicycle needs and choose a preferred day. We will confirm the details before anything is booked.', 'northside-booking' ); ?></p>
        <ol class="nsb-steps"><li><?php esc_html_e( 'Choose your service', 'northside-booking' ); ?></li><li><?php esc_html_e( 'Send a request', 'northside-booking' ); ?></li><li><?php esc_html_e( 'Wait for confirmation', 'northside-booking' ); ?></li></ol>
        <p class="nsb-sample"><?php esc_html_e( 'Invented shop. Sample data only. Please use fictional details in this demo.', 'northside-booking' ); ?></p>
    </aside>
    <div class="nsb-panel">
        <div class="nsb-panel-head"><span class="nsb-kicker"><?php esc_html_e( 'BOOKING REQUEST', 'northside-booking' ); ?></span><h3><?php esc_html_e( 'Let’s get you rolling.', 'northside-booking' ); ?></h3><p><?php esc_html_e( 'All fields are required except phone and notes.', 'northside-booking' ); ?></p></div>
        <div class="nsb-message <?php echo $success ? 'nsb-success' : ''; ?>" role="status" aria-live="polite" tabindex="-1" <?php echo '' === $message ? 'hidden' : ''; ?>><?php echo esc_html( $message ); ?></div>
        <form class="nsb-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-endpoint="<?php echo esc_url( rest_url( 'northside-booking/v1/requests' ) ); ?>" data-rest-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>" data-failure="<?php esc_attr_e( 'The connection was interrupted. Your request may have been saved. Check before sending again, or reload to use the standard form.', 'northside-booking' ); ?>" novalidate>
            <input type="hidden" name="action" value="nsb_submit">
            <input type="hidden" name="nsb_return" value="<?php echo esc_url( $return_url ); ?>">
            <?php wp_nonce_field( 'nsb_submit', 'nsb_nonce', false ); ?>
            <div class="nsb-hp" aria-hidden="true"><label><?php esc_html_e( 'Leave this empty', 'northside-booking' ); ?><input name="website" type="text" tabindex="-1" autocomplete="off"></label></div>
            <?php
            $fields = array(
                'name' => array( __( 'Name', 'northside-booking' ), 'text', 'name', 100 ),
                'email' => array( __( 'Email', 'northside-booking' ), 'email', 'email', 254 ),
                'phone' => array( __( 'Phone (optional)', 'northside-booking' ), 'tel', 'tel', 40 ),
                'service' => array( __( 'Service', 'northside-booking' ), 'select', 'off', 100 ),
                'date' => array( __( 'Preferred date', 'northside-booking' ), 'date', 'off', 10 ),
                'notes' => array( __( 'Notes (optional)', 'northside-booking' ), 'textarea', 'off', 2000 ),
            );
            foreach ( $fields as $field => $spec ) :
                $value = isset( $values[ $field ] ) ? $values[ $field ] : '';
                $error = isset( $errors[ $field ] ) ? $errors[ $field ] : '';
                $required = ! in_array( $field, array( 'phone', 'notes' ), true );
                ?>
                <div class="nsb-field <?php echo 'notes' === $field ? 'nsb-wide' : ''; ?>">
                    <label for="<?php echo esc_attr( $id . $field ); ?>"><?php echo esc_html( $spec[0] ); ?></label>
                    <?php if ( 'select' === $spec[1] ) : ?>
                        <select id="<?php echo esc_attr( $id . $field ); ?>" name="service" required aria-describedby="<?php echo esc_attr( $id . $field ); ?>-error" aria-invalid="<?php echo $error ? 'true' : 'false'; ?>"><option value=""><?php esc_html_e( 'Choose a service', 'northside-booking' ); ?></option><?php foreach ( $settings['services'] as $service ) : ?><option value="<?php echo esc_attr( $service ); ?>" <?php selected( $value, $service ); ?>><?php echo esc_html( $service ); ?></option><?php endforeach; ?></select>
                    <?php elseif ( 'textarea' === $spec[1] ) : ?>
                        <textarea id="<?php echo esc_attr( $id . $field ); ?>" name="notes" rows="3" maxlength="2000" aria-describedby="<?php echo esc_attr( $id . $field ); ?>-error" aria-invalid="<?php echo $error ? 'true' : 'false'; ?>"><?php echo esc_textarea( $value ); ?></textarea>
                    <?php else : ?>
                        <input id="<?php echo esc_attr( $id . $field ); ?>" name="<?php echo esc_attr( $field ); ?>" type="<?php echo esc_attr( $spec[1] ); ?>" value="<?php echo esc_attr( $value ); ?>" maxlength="<?php echo esc_attr( $spec[3] ); ?>" autocomplete="<?php echo esc_attr( $spec[2] ); ?>" <?php echo $required ? 'required' : ''; ?> <?php if ( 'date' === $field ) { echo 'min="' . esc_attr( current_time( 'Y-m-d' ) ) . '"'; } ?> aria-describedby="<?php echo esc_attr( $id . $field ); ?>-error" aria-invalid="<?php echo $error ? 'true' : 'false'; ?>">
                    <?php endif; ?>
                    <span class="nsb-error" id="<?php echo esc_attr( $id . $field ); ?>-error" data-error-for="<?php echo esc_attr( $field ); ?>"><?php echo esc_html( $error ); ?></span>
                </div>
            <?php endforeach; ?>
            <div class="nsb-wide nsb-submit"><button type="submit"><?php esc_html_e( 'Send booking request', 'northside-booking' ); ?><span aria-hidden="true"> ↗</span></button><p><?php esc_html_e( 'This sends a request, not a confirmed booking. No payment is taken.', 'northside-booking' ); ?></p></div>
        </form>
    </div>
</section>
