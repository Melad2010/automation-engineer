<?php
/** Remove configuration/capability; remove requests only with explicit opt-in. */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
$nsb_settings = get_option( 'nsb_settings', array() );
if ( ! empty( $nsb_settings['delete_data'] ) ) {
    do {
        $nsb_ids = get_posts( array( 'post_type' => 'nsb_request', 'post_status' => array( 'private', 'publish', 'draft', 'pending', 'future', 'trash' ), 'posts_per_page' => 100, 'fields' => 'ids' ) );
        $nsb_deleted = 0;
        foreach ( $nsb_ids as $nsb_id ) {
            if ( wp_delete_post( $nsb_id, true ) ) {
                ++$nsb_deleted;
            }
        }
    } while ( $nsb_ids && $nsb_deleted );
}
foreach ( array_keys( get_option( 'nsb_transients', array() ) ) as $nsb_transient ) {
    delete_transient( $nsb_transient );
}
delete_option( 'nsb_transients' );
delete_option( 'nsb_settings' );
foreach ( wp_roles()->roles as $nsb_role_name => $nsb_role_data ) {
    $nsb_role = get_role( $nsb_role_name );
    if ( $nsb_role ) {
        $nsb_role->remove_cap( 'manage_nsb_requests' );
    }
}
