=== Northside Booking Requests ===
Tags: booking, requests, bicycle, sample
Requires at least: 6.4
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A small booking-request plugin for an invented bicycle workshop. All demo data is synthetic.

== Description ==

Use [northside_booking] or the Northside Booking dynamic block. Requests are private custom posts. Administrators can manage four states, filter requests, see dashboard counts, and configure services, notification email and success text with the Settings API.

No build step, external service or runtime library. The form works with normal POST/redirect and progressively enhances with fetch. Validation is shared by both endpoints. Nonces, a honeypot and five attempts per hashed visitor address per ten minutes guard intake.

The plugin does not reserve calendar capacity, accept payment, or confirm appointments automatically. Northside Bike Repair is invented. Demo visitors should enter fictional information only.

== Installation ==

1. Upload northside-booking.zip in Plugins > Add New > Upload Plugin and activate on a single site.
2. Open Booking requests > Settings; set a notification email you control.
3. Add [northside_booking] to a page, or insert the Northside Booking block.
4. Review new requests in Booking requests and use the state row actions.

== Frequently Asked Questions ==

= Where is data stored? =
In private WordPress posts and registered post meta. Temporary form notices expire after five minutes. Rate limits use a salted HMAC of the remote address; no raw address is stored by this plugin. WordPress or your host may log requests separately.

= Does wp_mail guarantee delivery? =
No. The list shows whether WordPress handed the notification to its mailer. Verify mail delivery on your host. Playground demo mail is suppressed.

= What does uninstall remove? =
Settings, indexed temporary data and the custom role capability. Requests stay unless Uninstall cleanup was explicitly enabled. Deactivation preserves data. Network activation is unsupported; activate separately per site.

= Can the form page be cached? =
Exclude it and its notice query strings from full-page caches, or stale nonces and notices can be served. Rate limiting is a small best-effort transient guard, not an atomic abuse-prevention service; visitors sharing an address share its limit.

== Changelog ==

= 1.0.0 =
Initial synthetic proof-library sample.
